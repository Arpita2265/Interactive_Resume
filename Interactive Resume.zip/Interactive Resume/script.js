function showSection(id) {
  // Hide all sections
  document.querySelectorAll('.section').forEach(section => {
    section.classList.remove('active');
  });

  // Remove active class from all buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });

  // Show selected section and highlight the clicked button
  document.getElementById(id).classList.add('active');
  event.target.classList.add('active');
}
